﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication2
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //StringBuilder sb = new StringBuilder();
        }

        [WebMethod()]
        //[System.Web.Script.Services.ScriptMethod(UseHttpGet = true, ResponseFormat = System.Web.Script.Services.ResponseFormat.Json)]
        public static String GetData(string name, string startdate, string enddate)
        {
            DataTable dt = new DataTable();
            string strEOAssessmentReport = eoAssessmentReport(dt);
            return Convert.ToString(strEOAssessmentReport);
        }

        public static string eoAssessmentReport(DataTable dtEOAssessmentReport){
            
            StringBuilder sb = new StringBuilder();

            sb.Append("<table id='example' class='table table-striped table-bordered' style='width: 100%'>");
            sb.Append("<thead>");   
             sb.Append("<tr>");
            sb.Append("<th>Insured Name</th>");
            sb.Append("<th>Email ID</th>");
            sb.Append("<th>Title</th>");
            sb.Append("<th>Company</th>");
            sb.Append("<th>Start Date</th>");
            sb.Append("<th>End Date</th>");
            sb.Append("<th>Completion Date</th>");
            sb.Append("<th>Grade</th>");
            sb.Append("<th>Details</th>");
            sb.Append("</tr>");
            sb.Append("</thead>");
            sb.Append("<tbody>");
            for (int i=1; i<=1000; i++)
            {
                sb.Append("<tr>");
                sb.Append("<td>Insured Name '"+i+"'</td>");
                sb.Append("<td>Email ID '" + i + "'</td>");
                sb.Append("<td>Title '" + i + "'</td>");
                sb.Append("<td>Company '" + i + "'</td>");
                sb.Append("<td>Start Date '" + i + "'</td>");
                sb.Append("<td>End Date '" + i + "'</td>");
                sb.Append("<td>Completion Date '" + i + "'</td>");
                sb.Append("<td>Grade '" + i + "'</td>");
                sb.Append("<td>Details '" + i + "'</td>");

                sb.Append("</tr>");

            }
            sb.Append("</tbody>");
            sb.Append("</table>");

            //foreach (DataRow dr in ndt.Rows)
            //{
            //    row = new Dictionary<string, object>();
            //    foreach (DataColumn dc in ndt.Columns)
            //    {
            //        row.Add(dc.ColumnName.Trim(), dr[dc]);
            //    }
            //    rows.Add(row);
            //}


            return Convert.ToString(sb);
        }
    }
}